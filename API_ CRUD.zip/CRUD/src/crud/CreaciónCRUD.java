/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

/**
 *
 * @author omarp
 */
public class CreaciónCRUD {

    import java.sql.*;

    public class CRUDExample {

        private static final String URL = "jdbc:mysql://localhost:3306/EventosEscom";
        private static final String USUARIO = "root";
        private static final String CONTRASEÑA = "1203";

        public static void main(String[] args) {
            Connection conexion = null;
            try {
                // Establecer conexión
                conexion = DriverManager.getConnection(URL, USUARIO, CONTRASEÑA);

                // Ejemplos de operaciones CRUD
                insertarEvento(conexion, "Descripción del evento 1", "2024-01-11", "Evento 1");
                insertarAsistente(conexion, "correo@ejemplo.com", "2024-01-11", "ApellidoMaterno", "Nombre", "ApellidoPaterno", 1);
                mostrarEventos(conexion);
                mostrarAsistentes(conexion);
                actualizarEvento(conexion, 1, "Descripción actualizada");
                mostrarEventos(conexion);
                eliminarAsistente(conexion, 1);
                mostrarAsistentes(conexion);

            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                // Cerrar la conexión
                if (conexion != null) {
                    try {
                        conexion.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        // Operaciones CRUD para la tabla Evento
        private static void insertarEvento(Connection conexion, String descripcion, String fechaCreacion, String nombre) throws SQLException {
            String sql = "INSERT INTO Evento(descripcionEvento, fechaCreacion, nombreEvento) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
                pstmt.setString(1, descripcion);
                pstmt.setDate(2, Date.valueOf(fechaCreacion));
                pstmt.setString(3, nombre);
                pstmt.executeUpdate();
                System.out.println("Evento insertado correctamente.");
            }
        }

        private static void mostrarEventos(Connection conexion) throws SQLException {
            String sql = "SELECT * FROM Evento";
            try (Statement stmt = conexion.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                System.out.println("\nEventos:");
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("idEvento")
                            + ", Descripción: " + rs.getString("descripcionEvento")
                            + ", Fecha Creación: " + rs.getDate("fechaCreacion")
                            + ", Nombre: " + rs.getString("nombreEvento"));
                }
            }
        }

        private static void actualizarEvento(Connection conexion, int idEvento, String nuevaDescripcion) throws SQLException {
            String sql = "UPDATE Evento SET descripcionEvento = ? WHERE idEvento = ?";
            try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
                pstmt.setString(1, nuevaDescripcion);
                pstmt.setInt(2, idEvento);
                pstmt.executeUpdate();
                System.out.println("Evento actualizado correctamente.");
            }
        }

        // Operaciones CRUD para la tabla Asistente
        private static void insertarAsistente(Connection conexion, String email, String fechaRegistro, String materno, String nombre, String paterno, int idEvento) throws SQLException {
            String sql = "INSERT INTO Asistente(email, fechaRegistro, materno, nombre, paterno, idEvento) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
                pstmt.setString(1, email);
                pstmt.setDate(2, Date.valueOf(fechaRegistro));
                pstmt.setString(3, materno);
                pstmt.setString(4, nombre);
                pstmt.setString(5, paterno);
                pstmt.setInt(6, idEvento);
                pstmt.executeUpdate();
                System.out.println("Asistente insertado correctamente.");
            }
        }

        private static void mostrarAsistentes(Connection conexion) throws SQLException {
            String sql = "SELECT * FROM Asistente";
            try (Statement stmt = conexion.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
                System.out.println("\nAsistentes:");
                while (rs.next()) {
                    System.out.println("ID: " + rs.getInt("idAsistente")
                            + ", Email: " + rs.getString("email")
                            + ", Fecha Registro: " + rs.getDate("fechaRegistro")
                            + ", Materno: " + rs.getString("materno")
                            + ", Nombre: " + rs.getString("nombre")
                            + ", Paterno: " + rs.getString("paterno")
                            + ", ID Evento: " + rs.getInt("idEvento"));
                }
            }
        }

        private static void eliminarAsistente(Connection conexion, int idAsistente) throws SQLException {
            String sql = "DELETE FROM Asistente WHERE idAsistente = ?";
            try (PreparedStatement pstmt = conexion.prepareStatement(sql)) {
                pstmt.setInt(1, idAsistente);
                pstmt.executeUpdate();
                System.out.println("Asistente eliminado correctamente.");
            }
        }
    }

}
