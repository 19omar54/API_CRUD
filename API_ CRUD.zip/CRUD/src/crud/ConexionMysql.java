/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

import com.sun.jdi.connect.spi.Connection;
import java.sql.DriverManager;
/**
 *
 * @author omarp
 */
public class ConexionMysql {
    Connection cn;
    public Connection conectar(){
        try {

            Class. forName ("com-mysql. jdbc.Driver");
            cn = (Connection) DriverManager.getConnection ("jdbc:mysq://localhost/EventosEscom","root","");
            System. out.println("CONECTADO");
        }catch (Exception e) {
            System. out.println ("ERROR"+e);
        }    
        return cn;
}
}