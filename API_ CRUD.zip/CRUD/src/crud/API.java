/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 *
 * @author omarp
 */
public class API {

    @RestController
    @RequestMapping("/api")
    public class ApiController {

        @PostMapping("/generar-reporte-pdf")
        public String generarReportePDF() {
            try {
                String nombreArchivo = "informe.pdf";
                String rutaArchivo = CARPETA_PDF + nombreArchivo;

                Document document = new Document();
                PdfWriter.getInstance(document, new FileOutputStream(new File(rutaArchivo)));

                document.open();
                document.add(new Paragraph("Contenido del informe en PDF"));
                document.close();

                return "Informe PDF generado exitosamente.";
            } catch (DocumentException | IOException e) {
                e.printStackTrace();
                return "Error al generar el informe PDF.";
            }
        }
    return "Informe PDF generado exitosamente.";
        }

        @PostMapping("/subir-archivo")
    public String subirArchivo(@RequestParam("file") MultipartFile file) {
        File destFile = new File(CARPETA_ARCHIVOS + fileName);
        file.transferTo(destFile);

        return "Archivo subido exitosamente.";
    }

    public String enviarCorreo() {
        final String correoRemitente = "tucorreo@gmail.com";
        final String contraseñaRemitente = "tucontraseña";

        Properties propiedades = new Properties();
        propiedades.put("mail.smtp.auth", "true");
        propiedades.put("mail.smtp.starttls.enable", "true");
        propiedades.put("mail.smtp.host", "smtp.gmail.com");
        propiedades.put("mail.smtp.port", "587");

        Session sesion = Session.getInstance(propiedades, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(correoRemitente, contraseñaRemitente);
            }
        });

        try {
            Message mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress(correoRemitente));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse("destinatario@dominio.com"));
            mensaje.setSubject("Asunto del correo");
            mensaje.setText("Cuerpo del correo electrónico");

            Transport.send(mensaje);

            return "Correo electrónico enviado exitosamente.";
        } catch (MessagingException e) {
            e.printStackTrace();
            return "Error al enviar el correo electrónico.";
        }
    }

return "Archivo subido exitosamente.";
        }
            return "Correo electrónico enviado exitosamente.";
        }

    }

}
